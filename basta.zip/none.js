function calculateBMI() {
    // Get the height and weight from the input fields
    const heightInput = document.getElementById('height').value;
    const weight = parseFloat(document.getElementById('weight').value);

    // Validate weight input
    if (isNaN(weight) || weight <= 0) {
        alert("Please enter a valid weight.");
        return;
    }

    // Parse height input (e.g., "5'7")
    const heightParts = heightInput.split("'");

    // Validate height input
    if (heightParts.length !== 2 || isNaN(heightParts[0]) || isNaN(heightParts[1])) {
        alert("Please enter a valid height in the format 'feet'inches'.");
        return;
    }

    const feet = parseInt(heightParts[0]);
    const inches = parseInt(heightParts[1]);

    // Convert height to total inches
    const totalInches = (feet * 12) + inches;

    // Convert height to meters (1 inch = 0.0254 meters)
    const heightInMeters = totalInches * 0.0254;

    // Calculate BMI
    const bmi = weight / (heightInMeters * heightInMeters);

    // Determine BMI category
    let category = '';
    
    if (bmi < 18.5) {
        category = 'Underweight';
    } else if (bmi >= 18.5 && bmi < 24.9) {
        category = 'Normal weight';
    } else if (bmi >= 25 && bmi < 29.9) {
        category = 'Overweight';
    } else {
        category = 'Obesity';
    }

    // Display the result
    const resultElement = document.getElementById('result');
    resultElement.innerText = `Your BMI is ${bmi.toFixed(2)} (${category}).`;
}

function resetFields() {
    document.getElementById('height').value = '';
    document.getElementById('weight').value = '';
    document.getElementById('result').innerText = '';
}